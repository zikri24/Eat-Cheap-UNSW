vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|28 Apr 2015 03:20:37 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|OMAR\\Zikri
vti_modifiedby:SR|OMAR\\Zikri
vti_timecreated:TR|28 Apr 2015 03:20:37 -0000
vti_cacheddtm:TX|28 Apr 2015 03:20:37 -0000
vti_filesize:IR|59250
vti_backlinkinfo:VX|
